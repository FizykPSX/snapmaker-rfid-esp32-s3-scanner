# Skaner tagów filamentu — obudowa R3

R3 uwzględnia uwagi po wydruku R2. Wszystkie cztery części mają nowy wspólny zestaw plików. Nie mieszaj połówek R2 i R3.

## Zmiany

1. Kołnierz ustalający ma lokalne wybrania wokół czterech tulei. Promień wybrania 4,45 mm zapewnia 0,45 mm nominalnego luzu względem tulei o promieniu 4 mm. Dodatkowe wybranie znajduje się przy prowadnicach przycisku.
2. Podpory RC522 podniesiono dokładnie o 3 mm: siedzisko PCB na Z=6,6 mm zamiast 3,6 mm. Wysokość słupka nad dnem wynosi teraz 5 mm. Kołki pozycjonujące mają nadal 1,6 mm wysokości.
3. Uchwyt przycisku ma równy, symetryczny kołnierz 21 × 14,2 × 1,2 mm. Wsuwa się od góry w prowadnice tylnej połówki. Szczelina ma 1,8 mm szerokości, czyli 0,3 mm luzu z każdej strony kołnierza. Dno zatrzymuje ruch w dół; górna połówka zatrzymuje wysunięcie w górę.
4. Przycisk pozostaje na dolnej ściance pod ekranem. Panel znajduje się teraz przy zewnętrznej ściance, dzięki czemu korpus odsuwa się od podniesionej płytki RFID. Cap wystaje około 2 mm poza obudowę.
5. Usunięto otwartą wnękę w obu połówkach. Ścianka otacza panel przycisku, a USB ma osobny, zamknięty tunel o otworze 17 × 10 mm, promieniu narożników 2 mm i długości 17,2 mm. Minimalna grubość dolnej ścianki tunelu wynosi 1,2 mm, bocznych 2,5 mm. Dostęp do gniazda jest zagłębiony; zweryfikuj długość i obrys własnej wtyczki.
6. Śruby obudowy wkłada się wyłącznie od spodu. Górne gniazda są ślepe; na powierzchni przy ekranie nie ma otworów śrub. Nie ma już sześciokątnych kieszeni na nakrętki.

## Śruby i inserty

- Gwint M3, długość pod łbem 11,76 mm; całkowita długość 13,76 mm według pomiaru użytkownika. Z tego wynika wysokość łba 2 mm.
- Otwory przelotowe w tylnej połówce: Ø3,4 mm.
- Zagłębienie na łeb: Ø6,4 mm, dno oporowe na głębokości 11 mm od zewnętrznego spodu. Wierzch łba znajduje się 9 mm pod powierzchnią.
- Górne gniazdo: Ø3,4 mm, ślepe, głębokość 6,5 mm od powierzchni tulei. Średnica została zachowana na wyraźne życzenie użytkownika.
- Przy złożeniu nominalnym śruba sięga 5,51 mm w obszar górnego gniazda i pozostawia 0,99 mm do jego dna.
- Wymiary zewnętrzne i długość insertów nie zostały podane. Nie potwierdzono pasowania konkretnego insertu. Ø3,4 mm jest zachowanym otworem, a nie uniwersalnym wymiarem pod każdy insert M3. Przed osadzeniem porównaj go ze swoim insertem; ewentualna korekta dotyczy wyłącznie ślepych gniazd górnej części.

Pozostałe elementy: 4 śruby M2 × 5 do fabrycznych tulejek Waveshare; 4 krótkie M2 × 4 z tworzywa do RC522; 2 śruby M2 × 8 do poprzeczki przycisku; 2 opaski do 3 mm szerokości i poniżej 1 mm grubości oraz miękka pianka pod ogniwo.

## Pliki do druku

- Filament_Tag_Scanner_R3.3mf — cztery części w milimetrach, rozłożone bez nakładania na obszarze 180 × 180 mm.
- STL/01_rear_tray.stl — tylna połówka, wyższe słupki, prowadnice i głębokie zagłębienia łbów.
- STL/02_front_cover.stl — przednia połówka, zamknięty tunel USB i ślepe gniazda.
- STL/03_switch_carrier.stl — nowy uchwyt z symetrycznym kołnierzem.
- STL/04_switch_retainer.stl — poprzeczka przycisku.
- Filament_Tag_Scanner_R3.f3d — złożenie Fusion z historią operacji i modelami odniesienia elektroniki.
- STEP/ — cztery osobne części w lokalnych układach współrzędnych. Złożenie znajduje się w F3D.
- validation_fusion.json i validation_meshes.json — wyniki kontroli CAD i siatek.

STL i 3MF są ustawione do druku, najniższy punkt każdej części leży na Z=0. Plik 3MF zawiera samą geometrię, bez profilu drukarki, podpór, temperatur i G-code. Nie skaluj modeli.

## Druk

Punkt wyjścia: PETG, dysza 0,4 mm, warstwa 0,2 mm, 4 obrysy, 4–5 pełnych warstw góry i dołu, 20% wypełnienia.

- Tył: zewnętrznym spodem do stołu. Sprawdź mosty kanałów opasek i sklepienia głębokich zagłębień na łby; podpory nie mogą zostać uwięzione w otworach śrub.
- Przód: powierzchnią przy ekranie do stołu. Dodaj lokalne, usuwalne podpory pod uchwyty Waveshare i most tunelu USB. Tunel pozostaje dostępny z obu końców przed montażem elektroniki.
- Uchwyt przycisku: panelem do stołu. Podeprzyj wystający kołnierz.
- Poprzeczka: płasko, opcjonalnie mały brim.

Modele REF_ w Fusion służą tylko do sprawdzania przestrzeni; nie drukuj ich. Slicer musi pokazywać dokładnie cztery części.

## Montaż

1. Usuń podpory i zadziory. Przymierz puste połówki, przesuw kołnierza w prowadnicach oraz wtyk USB.
2. Dopasuj i osadź cztery inserty od wewnętrznej strony górnej połówki, przed montażem elektroniki. Nie pogłębiaj gniazd w stronę zewnętrznej powierzchni.
3. Przykręć Waveshare do fabrycznych tulejek śrubami M2 × 5, bez naprężania szkła.
4. Przykręć RC522 do podniesionych słupków, złączem skierowanym przeciwnie do przycisku. Rozstaw mocowań pochodzi z dostarczonego modelu RC522.3mf.
5. Zamocuj ogniwo 66 mm, o maksymalnej średnicy 22 mm, w kołyskach Ø23 mm. Dopasuj piankę do węższej części 18,7 mm i załóż opaski bez zgniatania pakietu.
6. Wsuń przycisk do kieszeni 7,5 × 7,5 mm, załóż poprzeczkę i dokręć dwie śruby M2. Kołnierz kompletnego uchwytu wsuń pionowo od góry w prowadnice tylnej połówki do dolnego oporu. Nie wciskaj kołnierza od zewnątrz przez okno panelu.
7. Ułóż przewody poza tulejami, krawędzią zamknięcia i ruchem przycisku. Sprawdź skok przycisku, połączenie USB i odczyt tagu.
8. Nałóż przednią połówkę pionowo; domyka prowadnice uchwytu. Skręć od spodu czterema śrubami o podanej długości 11,76 mm pod łbem. Nie używaj starych śrub M3 × 30.

## Zakres kontroli

Kontrola obejmuje przecięcia rzeczywistych brył CAD, próbki drogi zamykania połówek i wsuwania uchwytu, zatrzymanie kołnierza, drogę wprowadzania śrub, ciągłość ścianek oraz prześwit kontrolnego obrysu wtyku 14 × 8 mm. Pliki raportów zawierają dokładne próbki i wyniki. Próbkowanie ruchu nie jest ciągłą symulacją mechanizmu.

Poprzednia kontrola R2 pomijała przecięcia z powodu błędnej interpretacji isValid dla tymczasowych brył Fusion. W R3 kontrola odczytuje objętość wyniku operacji logicznej bez tego filtra; potwierdzono w ten sposób kolizję tulei i kołnierza w R2.

Obrys PCB RC522 37,5 × 58 mm oraz obrysy wtyków Dupont pozostają modelami przybliżonymi. Przewody, luty, rzeczywiste inserty, skurcz wydruku i zasięg RFID wymagają przymiarki. R3 nie przeszedł jeszcze fizycznego wydruku próbnego.

## Źródła

Geometria odniesienia: modele użytkownika RC522.3mf i esp32+s3+touch+lcd+2.3mf, podane pomiary ogniwa i przycisku oraz oficjalny STEP Waveshare esp32-s3-touch-lcd-2_20241108.stp. Gabaryt obudowy pozostaje 77 × 86 × 34,2 mm, bez wystającego capa.
